document.querySelector('.icon').addEventListener('click', function () {
    const menu = document.querySelector('ul');
    menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
});
